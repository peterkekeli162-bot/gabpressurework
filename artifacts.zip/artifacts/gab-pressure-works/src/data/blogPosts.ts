export interface BlogPost {
  slug: string;
  cat: string;
  title: string;
  excerpt: string;
  date: string;
  author: string;
  readTime: string;
  imgKey: "blog1" | "blog2" | "blog3";
  body: { type: "paragraph" | "heading" | "list"; content?: string; items?: string[] }[];
}

export const blogPosts: BlogPost[] = [
  {
    slug: "hidden-cost-of-downtime",
    cat: "Business Tips",
    title: "The Hidden Cost of Downtime: Why Washing Bays in Accra Need Fast Repairs",
    excerpt: "Every hour your pressure washer is down costs you customers — and they may not come back. Here's the math washing bay owners in Accra need to hear.",
    date: "May 16, 2025",
    author: "GAB Pressure Works Team",
    readTime: "3 min read",
    imgKey: "blog1",
    body: [
      {
        type: "paragraph",
        content: "Every hour a washing bay in Accra is shut down costs real money. If your pressure washer fails at 10am on a busy Saturday, you lose customers to the bay down the street. By 2pm, you have lost GHS 300–GHS 500 in revenue that never comes back."
      },
      {
        type: "paragraph",
        content: "Most owners wait until the machine is completely dead before calling for help. That is the expensive way. A broken pump can take 3–5 days to source and replace. That is almost a full week of zero income, plus your regular customers may not return."
      },
      {
        type: "heading",
        content: "Same-Day Repairs Save More Than You Think"
      },
      {
        type: "paragraph",
        content: "Smart washing bay owners in areas like Madina, Adenta, and Kasoa use GAB PRESSURE WORKS for same-day repairs because they understand one thing: downtime is the real expense. A GHS 150 emergency repair today saves you from GHS 2,000 in lost revenue this week."
      },
      {
        type: "paragraph",
        content: "Do not wait for total failure. If your pressure is dropping or you hear strange noises from the pump, book a maintenance check now."
      }
    ]
  },
  {
    slug: "warning-signs-pump-needs-servicing",
    cat: "Maintenance Tips",
    title: "Warning Signs Your Washing Bay Pump Needs Servicing",
    excerpt: "Your pressure washer talks to you before it breaks down. Most washing bay owners in Accra ignore the warnings until it is too late. Don't be one of them.",
    date: "April 22, 2025",
    author: "GAB Pressure Works Team",
    readTime: "4 min read",
    imgKey: "blog2",
    body: [
      {
        type: "paragraph",
        content: "Your pressure washer talks to you before it breaks down. Most washing bay owners in Accra ignore the warnings until it is too late. Here are 3 signs that mean you should call GAB PRESSURE WORKS today, not next week."
      },
      {
        type: "heading",
        content: "1. The Pressure Drops Mid-Wash"
      },
      {
        type: "paragraph",
        content: "If you start at full power but it weakens after 10 minutes, your pump seals are wearing out. Keep using it and you will burn the motor. A seal replacement costs a fraction of a full motor overhaul — catch it early."
      },
      {
        type: "heading",
        content: "2. Strange Noises or Vibration"
      },
      {
        type: "paragraph",
        content: "A healthy pump hums. If yours is knocking, grinding, or shaking the hose, internal parts are failing. That GHS 80 noise check today prevents a GHS 800 pump replacement next month."
      },
      {
        type: "heading",
        content: "3. Water Leaks Under the Machine"
      },
      {
        type: "paragraph",
        content: "Even small drips mean seals are gone. Water + electricity + metal = fast corrosion. One leak will destroy your pump and motor together."
      },
      {
        type: "paragraph",
        content: "Do not gamble with your income. If you notice any of these at your bay in Oyarifa, Haatso, or Tema, contact GAB PRESSURE WORKS for same-day diagnosis. Fast repair beats total replacement every time."
      }
    ]
  },
  {
    slug: "extend-life-of-pressure-hose",
    cat: "Pro Tips",
    title: "How to Extend the Life of Your Pressure Hose",
    excerpt: "Simple maintenance habits that prevent costly hose failures and keep your system running longer — tips every washing bay operator in Accra should know.",
    date: "April 10, 2025",
    author: "GAB Pressure Works Team",
    readTime: "3 min read",
    imgKey: "blog3",
    body: [
      {
        type: "paragraph",
        content: "A pressure hose is not just a tube — it is the lifeline of your entire washing system. And yet, it is the most neglected part on most bays. The result? Premature failures, leaks, and expensive replacements that could have been avoided with a few simple habits."
      },
      {
        type: "heading",
        content: "Never Kink the Hose"
      },
      {
        type: "paragraph",
        content: "Kinking is the fastest way to weaken the internal lining of a pressure hose. When you coil it at the end of a shift, always use wide loops — never tight folds. A kinked hose will fail at that exact point under high pressure."
      },
      {
        type: "heading",
        content: "Keep It Away from Heat Sources"
      },
      {
        type: "paragraph",
        content: "Running your hose near exhaust pipes, generators, or direct sunlight for extended periods degrades the outer sheath. Always route hoses away from heat. Store them in the shade when not in use."
      },
      {
        type: "heading",
        content: "Check the Couplings After Every Session"
      },
      {
        type: "paragraph",
        content: "Most hose leaks start at the coupling, not the body. A slightly loose coupling causes micro-vibrations under pressure that tear the hose fitting from the inside. Tighten and inspect couplings every day — it takes 30 seconds."
      },
      {
        type: "heading",
        content: "Flush Before Storage"
      },
      {
        type: "paragraph",
        content: "Always run clean water through the hose for 30 seconds before coiling and storing. Detergent residue left inside the lining causes internal corrosion over time. This single habit can double the lifespan of your hose."
      },
      {
        type: "paragraph",
        content: "Need replacement hoses or a full system inspection? GAB Pressure Works supplies pressure-rated hoses for every application and can inspect your entire setup at your washing bay location in Accra."
      }
    ]
  }
];
