import { useParams, Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowLeft, Clock, Calendar, User } from "lucide-react";
import { blogPosts } from "@/data/blogPosts";
import blog1 from "@/assets/images/blog-1.png";
import blog2 from "@/assets/images/blog-2.png";
import blog3 from "@/assets/images/blog-3.png";
import { useTheme } from "@/hooks/use-theme";
import { Sun, Moon } from "lucide-react";

const imgMap: Record<string, string> = { blog1, blog2, blog3 };

export default function BlogPost() {
  const { slug } = useParams<{ slug: string }>();
  const { theme, setTheme } = useTheme();
  const post = blogPosts.find((p) => p.slug === slug);

  if (!post) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background text-foreground gap-4">
        <h1 className="text-4xl font-display font-bold">Post Not Found</h1>
        <Link href="/#blog" className="text-primary underline">Back to Blog</Link>
      </div>
    );
  }

  const img = imgMap[post.imgKey];
  const related = blogPosts.filter((p) => p.slug !== slug).slice(0, 2);

  return (
    <div className="min-h-screen bg-background text-foreground font-sans">
      {/* Top nav bar */}
      <header className="fixed top-0 w-full z-50 backdrop-blur-md bg-background/80 border-b border-border">
        <div className="container mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 text-foreground hover:text-primary transition-colors">
            <ArrowLeft size={18} />
            <span className="font-display font-bold uppercase tracking-wide text-sm">GAB Pressure Works</span>
          </Link>
          <button
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="w-9 h-9 rounded-full flex items-center justify-center border border-border hover:border-primary transition-colors"
            data-testid="button-theme-toggle"
          >
            {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
          </button>
        </div>
      </header>

      {/* Hero image */}
      <div className="relative pt-16 h-[55vh] overflow-hidden">
        <img src={img} alt={post.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 container mx-auto px-4 md:px-8 pb-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-block text-xs font-bold uppercase tracking-widest text-primary bg-primary/10 border border-primary/20 px-3 py-1 rounded-full mb-4">
              {post.cat}
            </span>
            <h1 className="text-3xl md:text-5xl font-display font-bold leading-tight text-foreground max-w-3xl">
              {post.title}
            </h1>
          </motion.div>
        </div>
      </div>

      {/* Meta bar */}
      <div className="border-b border-border bg-muted/30">
        <div className="container mx-auto px-4 md:px-8 py-4 flex flex-wrap gap-5 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <Calendar size={14} className="text-primary" />
            <span>{post.date}</span>
          </div>
          <div className="flex items-center gap-2">
            <User size={14} className="text-primary" />
            <span>{post.author}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock size={14} className="text-primary" />
            <span>{post.readTime}</span>
          </div>
        </div>
      </div>

      {/* Body */}
      <div className="container mx-auto px-4 md:px-8 py-16">
        <div className="max-w-2xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="space-y-6"
          >
            {post.body.map((block, i) => {
              if (block.type === "heading") {
                return (
                  <h2
                    key={i}
                    className="text-2xl md:text-3xl font-display font-bold text-foreground mt-10 first:mt-0 border-l-4 border-primary pl-4"
                  >
                    {block.content}
                  </h2>
                );
              }
              if (block.type === "list" && block.items) {
                return (
                  <ul key={i} className="list-disc list-inside space-y-2 text-muted-foreground leading-relaxed">
                    {block.items.map((item, j) => (
                      <li key={j}>{item}</li>
                    ))}
                  </ul>
                );
              }
              return (
                <p key={i} className="text-foreground/80 leading-relaxed text-lg">
                  {block.content}
                </p>
              );
            })}
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-16 rounded-2xl bg-gradient-to-br from-primary to-[#042F40] p-8 text-white text-center"
          >
            <h3 className="text-2xl md:text-3xl font-display font-bold uppercase mb-3">
              Need a Repair or Service?
            </h3>
            <p className="text-blue-100 mb-6 text-sm">
              GAB Pressure Works is at Achimota Mile 7 Bus Stop, Accra. Same-day repairs available.
            </p>
            <a
              href="https://wa.me/233XXXXXXXXX"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-primary font-bold uppercase tracking-wider px-8 py-3 rounded hover:bg-blue-50 transition-colors"
              data-testid="link-whatsapp-cta"
            >
              Chat With Us on WhatsApp
            </a>
          </motion.div>
        </div>
      </div>

      {/* Related posts */}
      {related.length > 0 && (
        <section className="bg-muted/30 py-16 border-t border-border">
          <div className="container mx-auto px-4 md:px-8">
            <h2 className="text-2xl md:text-3xl font-display font-bold uppercase text-foreground mb-10 text-center">
              More from the Knowledge Hub
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
              {related.map((p, i) => (
                <Link
                  key={i}
                  href={`/blog/${p.slug}`}
                  className="group bg-card border border-border rounded-lg overflow-hidden flex flex-col hover:border-primary transition-colors"
                  data-testid={`link-related-post-${i}`}
                >
                    <div className="h-36 overflow-hidden">
                      <img
                        src={imgMap[p.imgKey]}
                        alt={p.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                      />
                    </div>
                    <div className="p-5">
                      <div className="text-primary text-xs font-bold uppercase tracking-wider mb-2">{p.cat}</div>
                      <h3 className="font-display font-bold text-foreground text-lg leading-tight group-hover:text-primary transition-colors">
                        {p.title}
                      </h3>
                      <p className="text-xs text-muted-foreground mt-3 font-medium">{p.date}</p>
                    </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Footer strip */}
      <footer className="bg-[#042F40] text-blue-200 py-6 text-center text-sm">
        <span>
          &copy; 2025 GAB Pressure Works. All Rights Reserved. | Achimota, Accra, Ghana
        </span>
      </footer>
    </div>
  );
}
