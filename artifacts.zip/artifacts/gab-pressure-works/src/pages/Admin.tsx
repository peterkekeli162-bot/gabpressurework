import { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { LogOut, RefreshCw, Search, Download, Users, MessageSquare, TrendingUp, Clock, Eye, EyeOff, Shield } from "lucide-react";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
const API = `${BASE}/api`;
const STORAGE_KEY = "gab_admin_token";

interface Enquiry {
  id: number;
  name: string;
  phone: string;
  email: string;
  service: string;
  message: string;
  createdAt: string;
}

interface Subscriber {
  id: number;
  email: string;
  createdAt: string;
}

// ── helpers ────────────────────────────────────────────────────────────
function fmtDate(iso: string) {
  return new Date(iso).toLocaleString("en-GB", {
    day: "2-digit", month: "short", year: "numeric",
    hour: "2-digit", minute: "2-digit",
  });
}

function isToday(iso: string) {
  const d = new Date(iso);
  const t = new Date();
  return d.getDate() === t.getDate() && d.getMonth() === t.getMonth() && d.getFullYear() === t.getFullYear();
}

function downloadCsv(filename: string, rows: Record<string, unknown>[]) {
  if (!rows.length) return;
  const headers = Object.keys(rows[0]);
  const csv = [
    headers.join(","),
    ...rows.map(r => headers.map(h => `"${String(r[h] ?? "").replace(/"/g, '""')}"`).join(",")),
  ].join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

// ── Login ──────────────────────────────────────────────────────────────
function Login({ onLogin }: { onLogin: (token: string) => void }) {
  const [pw, setPw] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setError("");
    try {
      const res = await fetch(`${API}/admin/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: pw }),
      });
      if (res.ok) {
        localStorage.setItem(STORAGE_KEY, pw);
        onLogin(pw);
      } else {
        setError("Wrong password. Try again.");
      }
    } catch {
      setError("Could not connect to server.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#042F40] flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-2xl shadow-2xl p-10 w-full max-w-sm"
      >
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-xl bg-[#0A7EA4]/10 flex items-center justify-center mb-4">
            <Shield size={28} className="text-[#0A7EA4]" />
          </div>
          <h1 className="text-2xl font-bold text-[#042F40] font-display uppercase tracking-wide">Admin Access</h1>
          <p className="text-gray-500 text-sm mt-1">GAB Pressure Works Dashboard</p>
        </div>
        <form onSubmit={submit} className="space-y-4">
          <div className="relative">
            <input
              type={show ? "text" : "password"}
              value={pw}
              onChange={e => setPw(e.target.value)}
              placeholder="Enter admin password"
              className="w-full px-4 py-3 rounded-lg border border-gray-200 text-gray-900 focus:ring-2 focus:ring-[#0A7EA4] outline-none pr-10 text-sm"
              data-testid="input-admin-password"
            />
            <button type="button" onClick={() => setShow(s => !s)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
              {show ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          {error && <p className="text-red-500 text-xs">{error}</p>}
          <button
            type="submit" disabled={loading || !pw}
            className="w-full bg-[#0A7EA4] text-white py-3 rounded-lg font-bold uppercase tracking-wider hover:bg-[#0A7EA4]/90 transition disabled:opacity-50 text-sm"
            data-testid="button-admin-login"
          >
            {loading ? "Checking..." : "Sign In"}
          </button>
        </form>
        <p className="text-center text-xs text-gray-400 mt-6">
          Only authorised personnel. All access is logged.
        </p>
      </motion.div>
    </div>
  );
}

// ── StatCard ───────────────────────────────────────────────────────────
function StatCard({ icon: Icon, label, value, sub, color }: {
  icon: React.ElementType; label: string; value: number | string; sub?: string; color: string;
}) {
  return (
    <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-xl border border-gray-100 p-6 shadow-sm">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs uppercase tracking-widest text-gray-500 font-semibold mb-1">{label}</p>
          <p className="text-3xl font-bold text-[#042F40]">{value}</p>
          {sub && <p className="text-xs text-gray-400 mt-1">{sub}</p>}
        </div>
        <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${color}`}>
          <Icon size={20} />
        </div>
      </div>
    </motion.div>
  );
}

// ── Dashboard ──────────────────────────────────────────────────────────
function Dashboard({ token, onLogout }: { token: string; onLogout: () => void }) {
  const [tab, setTab] = useState<"enquiries" | "newsletter">("enquiries");
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const [subscribers, setSubscribers] = useState<Subscriber[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const headers = { Authorization: `Bearer ${token}` };

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [eq, nl] = await Promise.all([
        fetch(`${API}/admin/enquiries`, { headers }).then(r => r.json()),
        fetch(`${API}/admin/newsletter`, { headers }).then(r => r.json()),
      ]);
      setEnquiries(Array.isArray(eq) ? eq : []);
      setSubscribers(Array.isArray(nl) ? nl : []);
    } catch { /* silent */ }
    setLoading(false);
  };

  useEffect(() => { fetchAll(); }, []);

  const filteredEnquiries = useMemo(() =>
    enquiries.filter(e =>
      `${e.name} ${e.email} ${e.phone} ${e.service} ${e.message}`.toLowerCase().includes(search.toLowerCase())
    ), [enquiries, search]);

  const filteredSubscribers = useMemo(() =>
    subscribers.filter(s => s.email.toLowerCase().includes(search.toLowerCase())),
    [subscribers, search]);

  const todayEnquiries = enquiries.filter(e => isToday(e.createdAt)).length;
  const todaySubscribers = subscribers.filter(s => isToday(s.createdAt)).length;

  const serviceLabels: Record<string, string> = {
    "pump-repair": "Pump Repair", "buy-pump": "Buy Pump",
    "buy-gun": "Buy Gun", "buy-hose": "Buy Hose",
    "buy-valve": "Valves & Fittings", "coating": "Coating",
    "other": "Other",
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top bar */}
      <header className="bg-[#042F40] text-white px-6 py-4 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3">
          <Shield size={20} className="text-[#0A7EA4]" />
          <span className="font-display font-bold uppercase tracking-wider text-sm">
            <span className="text-[#0A7EA4]">GAB</span> Admin
          </span>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={fetchAll} disabled={loading}
            className="flex items-center gap-1.5 text-xs text-blue-200 hover:text-white transition"
            data-testid="button-refresh">
            <RefreshCw size={13} className={loading ? "animate-spin" : ""} />
            Refresh
          </button>
          <button onClick={onLogout}
            className="flex items-center gap-1.5 text-xs bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded transition"
            data-testid="button-logout">
            <LogOut size={13} /> Sign Out
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <StatCard icon={MessageSquare} label="Total Enquiries" value={enquiries.length}
            sub={todayEnquiries > 0 ? `+${todayEnquiries} today` : "No new today"}
            color="bg-[#0A7EA4]/10 text-[#0A7EA4]" />
          <StatCard icon={Users} label="Subscribers" value={subscribers.length}
            sub={todaySubscribers > 0 ? `+${todaySubscribers} today` : "No new today"}
            color="bg-emerald-50 text-emerald-600" />
          <StatCard icon={TrendingUp} label="Today's Enquiries" value={todayEnquiries}
            color="bg-amber-50 text-amber-600" />
          <StatCard icon={Clock} label="New Subscribers" value={todaySubscribers}
            color="bg-purple-50 text-purple-600" />
        </div>

        {/* Tab bar + search + export */}
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 gap-4 flex-wrap">
            <div className="flex gap-1 bg-gray-100 rounded-lg p-1">
              {(["enquiries", "newsletter"] as const).map(t => (
                <button key={t} onClick={() => { setTab(t); setSearch(""); setExpandedId(null); }}
                  className={`px-4 py-1.5 rounded-md text-sm font-semibold transition ${
                    tab === t ? "bg-white text-[#042F40] shadow-sm" : "text-gray-500 hover:text-gray-700"
                  }`}>
                  {t === "enquiries" ? `Enquiries (${enquiries.length})` : `Subscribers (${subscribers.length})`}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-3 flex-1 min-w-0">
              <div className="relative flex-1 max-w-xs">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  value={search} onChange={e => setSearch(e.target.value)}
                  placeholder="Search..."
                  className="w-full pl-8 pr-4 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:ring-2 focus:ring-[#0A7EA4]/30"
                  data-testid="input-search"
                />
              </div>
              <button
                onClick={() => tab === "enquiries"
                  ? downloadCsv("enquiries.csv", filteredEnquiries as unknown as Record<string, unknown>[])
                  : downloadCsv("subscribers.csv", filteredSubscribers as unknown as Record<string, unknown>[])}
                className="flex items-center gap-1.5 text-xs bg-[#042F40] text-white px-4 py-2 rounded-lg hover:bg-[#042F40]/90 transition whitespace-nowrap"
                data-testid="button-export-csv"
              >
                <Download size={13} /> Export CSV
              </button>
            </div>
          </div>

          {/* Table */}
          {loading ? (
            <div className="flex items-center justify-center py-20 text-gray-400 text-sm gap-2">
              <RefreshCw size={16} className="animate-spin" /> Loading data...
            </div>
          ) : (
            <AnimatePresence mode="wait">
              {tab === "enquiries" ? (
                <motion.div key="enquiries" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                  {filteredEnquiries.length === 0 ? (
                    <div className="text-center py-16 text-gray-400">
                      <MessageSquare size={32} className="mx-auto mb-3 opacity-30" />
                      <p className="text-sm">{search ? "No results found" : "No enquiries yet"}</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-gray-50">
                      {filteredEnquiries.map((e, i) => (
                        <motion.div key={e.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: i * 0.03 }}>
                          <button
                            onClick={() => setExpandedId(expandedId === e.id ? null : e.id)}
                            className="w-full text-left px-6 py-4 hover:bg-gray-50 transition"
                            data-testid={`row-enquiry-${e.id}`}
                          >
                            <div className="flex items-start justify-between gap-4">
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-3 flex-wrap">
                                  <span className="font-semibold text-[#042F40] text-sm">{e.name}</span>
                                  <span className="text-xs bg-[#0A7EA4]/10 text-[#0A7EA4] px-2 py-0.5 rounded font-medium">
                                    {serviceLabels[e.service] ?? e.service}
                                  </span>
                                  {isToday(e.createdAt) && (
                                    <span className="text-xs bg-emerald-50 text-emerald-600 px-2 py-0.5 rounded font-medium">New</span>
                                  )}
                                </div>
                                <div className="flex gap-4 mt-1 flex-wrap">
                                  <a href={`tel:${e.phone}`} onClick={ev => ev.stopPropagation()}
                                    className="text-xs text-gray-500 hover:text-[#0A7EA4]">{e.phone}</a>
                                  <a href={`mailto:${e.email}`} onClick={ev => ev.stopPropagation()}
                                    className="text-xs text-gray-500 hover:text-[#0A7EA4]">{e.email}</a>
                                </div>
                              </div>
                              <span className="text-xs text-gray-400 whitespace-nowrap">{fmtDate(e.createdAt)}</span>
                            </div>
                            {expandedId === e.id && (
                              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }}
                                className="mt-3 pt-3 border-t border-dashed border-gray-200">
                                <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap">{e.message}</p>
                                <div className="flex gap-3 mt-3">
                                  <a href={`https://wa.me/${e.phone.replace(/\D/g, "")}?text=${encodeURIComponent(`Hi ${e.name}, thanks for your enquiry about ${serviceLabels[e.service] ?? e.service} at GAB Pressure Works.`)}`}
                                    target="_blank" rel="noopener noreferrer" onClick={ev => ev.stopPropagation()}
                                    className="text-xs bg-green-600 text-white px-3 py-1.5 rounded hover:bg-green-700 transition">
                                    Reply on WhatsApp
                                  </a>
                                  <a href={`mailto:${e.email}?subject=Re: Your Enquiry — GAB Pressure Works&body=Hi ${e.name},%0A%0AThank you for getting in touch.`}
                                    onClick={ev => ev.stopPropagation()}
                                    className="text-xs bg-[#042F40] text-white px-3 py-1.5 rounded hover:bg-[#042F40]/80 transition">
                                    Reply by Email
                                  </a>
                                </div>
                              </motion.div>
                            )}
                          </button>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </motion.div>
              ) : (
                <motion.div key="newsletter" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                  {filteredSubscribers.length === 0 ? (
                    <div className="text-center py-16 text-gray-400">
                      <Users size={32} className="mx-auto mb-3 opacity-30" />
                      <p className="text-sm">{search ? "No results found" : "No subscribers yet"}</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-gray-50">
                      {filteredSubscribers.map((s, i) => (
                        <motion.div key={s.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: i * 0.03 }}
                          className="px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition"
                          data-testid={`row-subscriber-${s.id}`}
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-[#0A7EA4]/10 flex items-center justify-center text-[#0A7EA4] text-xs font-bold uppercase">
                              {s.email[0]}
                            </div>
                            <a href={`mailto:${s.email}`} className="text-sm font-medium text-[#042F40] hover:text-[#0A7EA4] transition">
                              {s.email}
                            </a>
                            {isToday(s.createdAt) && (
                              <span className="text-xs bg-emerald-50 text-emerald-600 px-2 py-0.5 rounded font-medium">New</span>
                            )}
                          </div>
                          <span className="text-xs text-gray-400">{fmtDate(s.createdAt)}</span>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          )}
        </div>

        <p className="text-center text-xs text-gray-400 mt-8">
          GAB Pressure Works · Admin Dashboard · All data stored securely
        </p>
      </main>
    </div>
  );
}

// ── Main ───────────────────────────────────────────────────────────────
export default function Admin() {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem(STORAGE_KEY));

  const logout = () => {
    localStorage.removeItem(STORAGE_KEY);
    setToken(null);
  };

  if (!token) return <Login onLogin={setToken} />;
  return <Dashboard token={token} onLogout={logout} />;
}
