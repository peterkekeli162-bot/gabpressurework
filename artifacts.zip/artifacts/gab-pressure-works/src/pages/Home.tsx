import { useState, useEffect, useRef } from "react";
import { useTheme } from "@/hooks/use-theme";
import { Link } from "wouter";
import { Sun, Moon, Menu, X, ArrowDown, Zap, Wrench, Truck, Shield, MessageCircle, Send, ArrowRight, Phone, Mail, MapPin, Clock, ShoppingCart } from "lucide-react";
import { motion, AnimatePresence, useInView } from "framer-motion";
import { FaFacebook, FaInstagram, FaWhatsapp, FaEnvelope } from "react-icons/fa";
import { FaTiktok } from "react-icons/fa6";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useToast } from "@/hooks/use-toast";
import { useSubmitEnquiry, useSubscribeNewsletter } from "@workspace/api-client-react";

import heroBg from "@/assets/images/hero-bg.png";
import blog1 from "@/assets/images/blog-1.png";
import blog2 from "@/assets/images/blog-2.png";
import blog3 from "@/assets/images/blog-3.png";
import productPump from "@/assets/images/product-pump.png";
import productGun from "@/assets/images/product-gun.png";
import productHose from "@/assets/images/product-hose.png";
import productValve from "@/assets/images/product-valve.png";
import productCoating from "@/assets/images/product-coating.png";
import productRepair from "@/assets/images/product-repair.png";
import { blogPosts } from "@/data/blogPosts";

const imgMap: Record<string, string> = { blog1, blog2, blog3 };
const WHATSAPP = "233553949256";
const PHONE = "+233 (0) 55 394 9256";
const EMAIL = "gabpressureworks@gmail.com";

// ── WORD REVEAL ANIMATION ──────────────────────────────────────────────
const WordReveal = ({ text, className = "", delay = 0 }: { text: string; className?: string; delay?: number }) => {
  const words = text.split(" ");
  return (
    <span className={className}>
      {words.map((word, i) => (
        <motion.span
          key={i}
          initial={{ opacity: 0, y: 40, rotateX: -90 }}
          animate={{ opacity: 1, y: 0, rotateX: 0 }}
          transition={{ duration: 0.6, delay: delay + i * 0.12, ease: [0.22, 1, 0.36, 1] }}
          style={{ display: "inline-block", marginRight: "0.25em", transformOrigin: "bottom" }}
        >
          {word}
        </motion.span>
      ))}
    </span>
  );
};

// ── TYPEWRITER ─────────────────────────────────────────────────────────
const Typewriter = ({ text, delay = 0 }: { text: string; delay?: number }) => {
  const [displayed, setDisplayed] = useState("");
  const [started, setStarted] = useState(false);
  useEffect(() => {
    const timeout = setTimeout(() => setStarted(true), delay * 1000);
    return () => clearTimeout(timeout);
  }, [delay]);
  useEffect(() => {
    if (!started) return;
    let i = 0;
    const iv = setInterval(() => {
      setDisplayed(text.slice(0, ++i));
      if (i >= text.length) clearInterval(iv);
    }, 35);
    return () => clearInterval(iv);
  }, [started, text]);
  return <span>{displayed}<span className="animate-pulse text-primary">|</span></span>;
};

// ── COUNTER ────────────────────────────────────────────────────────────
const Counter = ({ value, suffix }: { value: number; suffix: string }) => {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!inView) return;
    let start = 0;
    const step = Math.ceil(value / 60);
    const iv = setInterval(() => {
      start = Math.min(start + step, value);
      setCount(start);
      if (start >= value) clearInterval(iv);
    }, 25);
    return () => clearInterval(iv);
  }, [inView, value]);
  return <span ref={ref}>{count}{suffix}</span>;
};

// ── NAVBAR ─────────────────────────────────────────────────────────────
const Navbar = () => {
  const { theme, setTheme } = useTheme();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  useEffect(() => {
    const fn = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);
  const navLinks = [
    { name: "Home", href: "#home" },
    { name: "Products", href: "#products" },
    { name: "Services", href: "#services" },
    { name: "About", href: "#about" },
    { name: "Blog", href: "#blog" },
    { name: "Contact", href: "#contact" },
  ];
  return (
    <>
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 backdrop-blur-md ${isScrolled ? "py-3 bg-background/90 shadow-md" : "py-5 bg-transparent"}`}>
        <div className="container mx-auto px-4 md:px-8 flex justify-between items-center">
          <a href="#home" className="text-xl font-display font-bold uppercase tracking-wide flex gap-1.5 items-center">
            <span className="text-primary">GAB</span>
            <span className="text-primary">PRESSURE</span>
            <span className="text-foreground">WORKS</span>
          </a>
          <div className="hidden md:flex items-center gap-7 font-medium">
            {navLinks.map((link) => (
              <a key={link.name} href={link.href} className="text-xs hover:text-primary transition-colors uppercase tracking-widest font-bold">
                {link.name}
              </a>
            ))}
            <button onClick={() => setTheme(theme === "dark" ? "light" : "dark")} className="p-2 rounded-full hover:bg-secondary transition-colors" data-testid="button-theme-toggle">
              {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <a href="#contact" className="bg-primary text-white px-5 py-2.5 rounded font-bold hover:bg-primary/90 transition uppercase tracking-wide text-xs shadow-lg shadow-primary/30" data-testid="link-get-quote">
              Get a Quote
            </a>
          </div>
          <div className="md:hidden flex items-center gap-3">
            <button onClick={() => setTheme(theme === "dark" ? "light" : "dark")} className="p-2">
              {theme === "dark" ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <button onClick={() => setIsMobileMenuOpen(true)} data-testid="button-mobile-menu"><Menu size={28} /></button>
          </div>
        </div>
      </nav>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }} transition={{ type: "tween", duration: 0.3 }}
            className="fixed inset-0 z-[60] bg-[#042F40] text-white flex flex-col p-8">
            <div className="flex justify-between items-center mb-12">
              <span className="text-2xl font-display font-bold">GAB PRESSURE WORKS</span>
              <button onClick={() => setIsMobileMenuOpen(false)} data-testid="button-close-menu"><X size={32} /></button>
            </div>
            <div className="flex flex-col gap-8 text-2xl font-display uppercase tracking-widest">
              {navLinks.map((link) => (
                <a key={link.name} href={link.href} onClick={() => setIsMobileMenuOpen(false)} className="hover:text-primary transition-colors">{link.name}</a>
              ))}
            </div>
            <div className="mt-auto text-sm text-blue-200">
              <p>{PHONE}</p>
              <p className="mt-1">{EMAIL}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

// ── HERO ───────────────────────────────────────────────────────────────
const Hero = () => {
  return (
    <section id="home" className="relative h-[100dvh] flex items-center overflow-hidden">
      {/* Background photo */}
      <div className="absolute inset-0 z-0">
        <img src={heroBg} alt="Pressure washing in action" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#042F40]/95 via-[#042F40]/75 to-[#0A7EA4]/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#042F40]/80 via-transparent to-transparent" />
      </div>

      {/* Animated ripple rings */}
      <div className="absolute inset-0 z-[1] overflow-hidden pointer-events-none">
        {[0, 1.2, 2.4].map((d, i) => (
          <div key={i} className="absolute top-1/2 right-1/4 -translate-y-1/2 border border-primary/20 rounded-full"
            style={{ width: `${500 + i * 200}px`, height: `${500 + i * 200}px`, marginLeft: `-${(500 + i * 200) / 2}px`, marginTop: `-${(500 + i * 200) / 2}px`, animation: `ping 4s cubic-bezier(0,0,0.2,1) ${d}s infinite` }} />
        ))}
      </div>

      <div className="container mx-auto px-4 relative z-20 text-white">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
          <p className="text-primary font-bold uppercase tracking-[0.3em] text-sm mb-4">
            <Typewriter text="Accra's No.1 Pressure Equipment Specialist" delay={0.3} />
          </p>
        </motion.div>

        <h1 className="font-display font-bold text-[clamp(3rem,8vw,7.5rem)] leading-[0.9] max-w-4xl uppercase">
          <WordReveal text="POWER IN" delay={0.8} />
          <br />
          <WordReveal text="EVERY DROP." className="text-primary" delay={1.2} />
        </h1>

        <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 1.8 }}
          className="mt-6 text-lg md:text-xl text-blue-100/90 max-w-xl font-light leading-relaxed">
          Sales, Repairs & Maintenance of Pressure Washing Equipment — Achimota Mile 7, Accra
        </motion.p>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 2.1 }}
          className="mt-10 flex flex-col sm:flex-row gap-4">
          <a href="#products" data-testid="link-explore-products"
            className="bg-primary text-white px-8 py-4 rounded font-bold uppercase tracking-wider hover:bg-primary/90 hover:shadow-[0_0_30px_rgba(10,126,164,0.5)] transition-all text-center text-sm shadow-[0_0_20px_rgba(10,126,164,0.4)]">
            Shop Our Products
          </a>
          <a href={`https://wa.me/${WHATSAPP}`} target="_blank" rel="noopener noreferrer" data-testid="link-chat-whatsapp"
            className="border-2 border-white text-white px-8 py-4 rounded font-bold uppercase tracking-wider hover:bg-white hover:text-[#042F40] transition-all text-center text-sm">
            Chat With Us
          </a>
        </motion.div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 2.5 }} className="mt-12 flex items-center gap-6 text-sm">
          <div className="flex items-center gap-2 text-blue-200">
            <Phone size={14} className="text-primary" />
            <a href={`tel:${PHONE}`} className="hover:text-primary transition-colors">{PHONE}</a>
          </div>
          <div className="flex items-center gap-2 text-blue-200">
            <Clock size={14} className="text-primary" />
            <span>Mon–Sat 8am–6pm</span>
          </div>
        </motion.div>
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 3, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 animate-bounce">
        <ArrowDown className="text-white/40" size={28} />
      </motion.div>
    </section>
  );
};

// ── PRODUCTS DISPLAY ───────────────────────────────────────────────────
const products = [
  { name: "Pressure Pumps", img: productPump, tag: "Bestseller", price: "Ask for Price", desc: "Industrial & domestic pumps. All major brands stocked." },
  { name: "Pressure Guns", img: productGun, tag: "In Stock", price: "Ask for Price", desc: "High-performance trigger guns for any pressure system." },
  { name: "Pressure Hoses", img: productHose, tag: "All Sizes", price: "Ask for Price", desc: "Pressure-rated hoses from 10m to 100m. Custom cuts available." },
  { name: "Valves & Fittings", img: productValve, tag: "In Stock", price: "Ask for Price", desc: "Brass & stainless fittings for all pressure systems." },
  { name: "Coating Solutions", img: productCoating, tag: "Professional", price: "Ask for Price", desc: "Surface protection coatings for long-lasting finishes." },
  { name: "Repair Services", img: productRepair, tag: "Same Day", price: "Free Diagnosis", desc: "Expert same-day pump & equipment repair at our Achimota workshop." },
];

const Products = () => {
  const [active, setActive] = useState(0);

  return (
    <section id="products" className="py-24 bg-background overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
          <p className="text-primary font-bold uppercase tracking-[0.3em] text-xs mb-3">What We Sell & Service</p>
          <h2 className="text-4xl md:text-6xl font-display font-bold uppercase text-foreground">Our Products</h2>
          <p className="mt-4 text-muted-foreground text-lg max-w-2xl mx-auto">
            Everything your pressure system needs — sold, fitted, and serviced at Achimota Mile 7.
          </p>
        </motion.div>

        {/* Featured Spotlight */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-0 rounded-2xl overflow-hidden border border-border mb-8 min-h-[480px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={active}
              initial={{ opacity: 0, scale: 1.05 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.97 }}
              transition={{ duration: 0.5 }}
              className="relative overflow-hidden"
            >
              <img src={products[active].img} alt={products[active].name} className="w-full h-full object-cover min-h-[300px] lg:min-h-[480px]" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#042F40]/90 via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 p-8 text-white">
                <span className="inline-block text-xs font-bold uppercase tracking-widest bg-primary px-3 py-1 rounded mb-3">{products[active].tag}</span>
                <h3 className="text-3xl md:text-4xl font-display font-bold uppercase mb-2">{products[active].name}</h3>
                <p className="text-blue-100 text-sm max-w-sm leading-relaxed">{products[active].desc}</p>
              </div>
            </motion.div>
          </AnimatePresence>

          <div className="bg-card flex flex-col justify-center p-8 gap-2">
            <p className="text-muted-foreground text-sm uppercase tracking-widest font-bold mb-4">Browse All Products</p>
            {products.map((p, i) => (
              <button
                key={i}
                data-testid={`button-product-${i}`}
                onClick={() => setActive(i)}
                className={`group flex items-center gap-4 p-4 rounded-xl transition-all border text-left ${
                  i === active ? "bg-primary/10 border-primary text-foreground" : "border-transparent hover:bg-muted text-muted-foreground hover:text-foreground"
                }`}
              >
                <div className={`w-12 h-12 rounded-lg overflow-hidden shrink-0 transition-all ${i === active ? "ring-2 ring-primary" : ""}`}>
                  <img src={p.img} alt={p.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-display font-bold uppercase text-sm leading-tight">{p.name}</div>
                  <div className={`text-xs mt-0.5 ${i === active ? "text-primary font-bold" : "text-muted-foreground"}`}>{p.price}</div>
                </div>
                {i === active && <ArrowRight size={16} className="text-primary shrink-0" />}
              </button>
            ))}

            <a
              href={`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(`Hi, I'm interested in ${products[active].name}. Please provide more details.`)}`}
              target="_blank" rel="noopener noreferrer"
              data-testid="link-order-whatsapp"
              className="mt-4 w-full bg-primary text-white py-4 rounded-lg font-bold uppercase tracking-wider text-sm text-center hover:bg-primary/90 hover:shadow-[0_0_20px_rgba(10,126,164,0.4)] transition-all flex items-center justify-center gap-2"
            >
              <ShoppingCart size={16} />
              Order / Enquire on WhatsApp
            </a>
          </div>
        </div>

        {/* Product card grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mt-4">
          {products.map((p, i) => (
            <motion.button
              key={i}
              data-testid={`button-product-thumb-${i}`}
              onClick={() => { setActive(i); document.getElementById("products")?.scrollIntoView({ behavior: "smooth" }); }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.07 }}
              className={`relative rounded-xl overflow-hidden aspect-square group cursor-pointer border-2 transition-all ${i === active ? "border-primary shadow-[0_0_20px_rgba(10,126,164,0.3)]" : "border-transparent"}`}
            >
              <img src={p.img} alt={p.name} className="w-full h-full object-cover group-hover:scale-110 transition duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#042F40]/80 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-2 text-white text-[10px] font-bold uppercase tracking-wide text-center leading-tight">{p.name}</div>
            </motion.button>
          ))}
        </div>
      </div>
    </section>
  );
};

// ── SERVICES ───────────────────────────────────────────────────────────
const Services = () => {
  const services = [
    { title: "Pressure Pumps", desc: "Industrial and domestic pumps supplied and serviced.", img: productPump },
    { title: "Pressure Guns", desc: "High-performance guns for professional cleaning results.", img: productGun },
    { title: "Valves & Fittings", desc: "Precision valve supply and replacement for all systems.", img: productValve },
    { title: "Hoses", desc: "Durable, pressure-rated hoses for every application.", img: productHose },
    { title: "Coating Solutions", desc: "Protective coatings for long-lasting surface performance.", img: productCoating },
    { title: "Pump Repairs", desc: "Fast, reliable repairs to get your equipment back in action.", img: productRepair },
  ];

  return (
    <section id="services" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-primary font-bold uppercase tracking-[0.3em] text-xs mb-3">Expert Services</p>
          <h2 className="text-4xl md:text-6xl font-display font-bold uppercase text-foreground">What We Do Best</h2>
          <p className="mt-4 text-muted-foreground text-lg">From pressure guns to pump overhauls — we've got every angle covered.</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group relative rounded-xl overflow-hidden border border-border hover:border-primary/50 transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_8px_40px_rgba(10,126,164,0.15)] cursor-pointer"
              data-testid={`card-service-${i}`}
            >
              {/* Photo background */}
              <div className="h-52 overflow-hidden relative">
                <img src={s.img} alt={s.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-700" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#042F40]/80 via-[#042F40]/20 to-transparent" />
              </div>
              <div className="bg-card p-6">
                <h3 className="text-xl font-display font-bold uppercase mb-2 text-foreground group-hover:text-primary transition-colors">{s.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{s.desc}</p>
                <a
                  href={`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(`I need help with: ${s.title}`)}`}
                  target="_blank" rel="noopener noreferrer"
                  className="mt-4 inline-flex items-center gap-1 text-primary text-xs font-bold uppercase tracking-wider hover:gap-2 transition-all"
                  data-testid={`link-service-whatsapp-${i}`}
                >
                  Enquire Now <ArrowRight size={12} />
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// ── WHY US ─────────────────────────────────────────────────────────────
const WhyUs = () => {
  const stats = [
    { value: 500, suffix: "+", label: "Happy Customers" },
    { value: 8, suffix: "+", label: "Years of Experience" },
    { value: 100, suffix: "%", label: "Satisfaction Guaranteed" },
  ];

  return (
    <section className="py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-[#042F40]" />
      <div className="absolute inset-0 opacity-10" style={{ backgroundImage: `url(${heroBg})`, backgroundSize: "cover", backgroundPosition: "center", filter: "blur(2px)" }} />
      <div className="absolute inset-0 bg-[#042F40]/70" />

      <div className="container mx-auto px-4 relative z-10">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-display font-bold uppercase text-white">
            Built on Trust. <span className="text-primary">Driven by Pressure.</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-16">
          {stats.map((s, i) => (
            <motion.div key={i} initial={{ opacity: 0, scale: 0.8 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.15 }}
              className="flex flex-col items-center text-center p-8 border border-white/10 rounded-xl bg-white/5 backdrop-blur">
              <div className="text-6xl md:text-7xl font-display font-bold text-primary mb-2">
                <Counter value={s.value} suffix={s.suffix} />
              </div>
              <div className="text-blue-100 uppercase tracking-widest text-sm font-semibold">{s.label}</div>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 border-t border-white/10 pt-12">
          {[
            { icon: Zap, label: "Fast Turnaround" },
            { icon: Wrench, label: "Expert Technicians" },
            { icon: Truck, label: "Equipment Supply" },
            { icon: Shield, label: "Quality Guaranteed" },
          ].map((v, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
              className="flex flex-col items-center text-center gap-4 text-white">
              <div className="w-14 h-14 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center">
                <v.icon size={26} className="text-primary" />
              </div>
              <span className="uppercase font-display font-bold tracking-wider text-sm">{v.label}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// ── ABOUT ──────────────────────────────────────────────────────────────
const About = () => {
  return (
    <section id="about" className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="pl-6 border-l-4 border-primary">
            <p className="text-primary font-bold uppercase tracking-[0.3em] text-xs mb-3">Our Story</p>
            <h2 className="text-4xl md:text-5xl font-display font-bold uppercase mb-6 text-foreground">Who We Are</h2>
            <div className="space-y-5 text-muted-foreground text-base leading-relaxed">
              <motion.p initial={{ opacity: 0, y: 15 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.2 }}>
                At GAB Pressure Works, we specialize in pressure washer repairs, pump maintenance, and the supply of quality pressure washing equipment and accessories. We provide reliable solutions for both residential and commercial clients, helping customers keep their machines operating efficiently and delivering professional cleaning results.
              </motion.p>
              <motion.p initial={{ opacity: 0, y: 15 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.35 }}>
                Our services include pump repairs, pressure gun servicing, valve replacement, hose supply, coating solutions, and home pressure washing services. With a focus on quality workmanship, fast response, and customer satisfaction, we are committed to building trust through dependable engineering solutions.
              </motion.p>
            </div>
            <motion.div initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.5 }} className="mt-8">
              <a href={`https://wa.me/${WHATSAPP}`} target="_blank" rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-primary text-white px-7 py-3.5 rounded font-bold uppercase tracking-wider text-sm hover:bg-primary/90 transition-all hover:shadow-[0_0_20px_rgba(10,126,164,0.4)]">
                Talk to Our Team
              </a>
            </motion.div>
          </motion.div>

          <motion.div initial={{ opacity: 0, x: 30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="grid grid-cols-2 gap-4">
            {[productPump, productGun, productHose, productRepair].map((img, i) => (
              <motion.div key={i} initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.12 }}
                className="rounded-xl overflow-hidden aspect-square border border-border group">
                <img src={img} alt="GAB Products" className="w-full h-full object-cover group-hover:scale-110 transition duration-700" />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

// ── TESTIMONIALS ───────────────────────────────────────────────────────
const reviews = [
  {
    name: "Kwame Asante",
    role: "Washing Bay Owner, Madina",
    stars: 5,
    text: "My pump broke on a Friday morning — peak business day. GAB came same afternoon, diagnosed and fixed it on the spot. I would have lost the whole weekend without them. These guys are the real deal.",
  },
  {
    name: "Abena Mensah",
    role: "Homeowner, East Legon",
    stars: 5,
    text: "I bought a pressure gun and hose from GAB and they fitted everything for me right there. Quality equipment, honest pricing. My compound has never looked this clean. Highly recommended.",
  },
  {
    name: "Emmanuel Tetteh",
    role: "Fleet Manager, Accra",
    stars: 5,
    text: "We service 30+ vehicles a week. GAB keeps our pressure system running without interruption. Fast response, expert repairs, and they always have parts in stock. Wouldn't go anywhere else.",
  },
  {
    name: "Ama Boateng",
    role: "Car Wash Business, Kasoa",
    stars: 5,
    text: "I've been using GAB for 3 years now. Every time there's an issue they sort it out quickly and explain what went wrong. The coaching they gave me on pump maintenance has saved me so much money.",
  },
  {
    name: "Francis Darko",
    role: "Industrial Contractor, Tema",
    stars: 5,
    text: "Sourced coating equipment and heavy-duty hoses from GAB for a commercial job. Everything arrived as specified, no shortcuts. Their knowledge of pressure systems is genuinely impressive.",
  },
  {
    name: "Gifty Owusu",
    role: "Residential Client, Achimota",
    stars: 5,
    text: "Called them about a leaking valve and they walked me through the diagnosis over the phone before I even visited. When I came in they fixed it in 20 minutes. Efficient, professional, and fair price.",
  },
];

const StarRating = ({ count }: { count: number }) => (
  <div className="flex gap-0.5">
    {Array.from({ length: count }).map((_, i) => (
      <svg key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" viewBox="0 0 20 20">
        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
      </svg>
    ))}
  </div>
);

const Testimonials = () => {
  const [current, setCurrent] = useState(0);
  const perPage = 3;
  const total = Math.ceil(reviews.length / perPage);
  const visible = reviews.slice(current * perPage, current * perPage + perPage);

  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
          <p className="text-primary font-bold uppercase tracking-[0.3em] text-xs mb-3">What Customers Say</p>
          <h2 className="text-4xl md:text-5xl font-display font-bold uppercase text-foreground">Real People. Real Results.</h2>
          <p className="mt-4 text-muted-foreground text-lg max-w-2xl mx-auto">
            Hundreds of washing bay owners and homeowners across Accra trust GAB Pressure Works.
          </p>
        </motion.div>

        <AnimatePresence mode="wait">
          <motion.div
            key={current}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.35 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10"
          >
            {visible.map((r, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08, duration: 0.35 }}
                className="bg-card border border-border rounded-xl p-7 flex flex-col gap-4 hover:border-primary/40 hover:shadow-[0_4px_30px_rgba(10,126,164,0.10)] transition-all"
                data-testid={`card-review-${i}`}
              >
                <StarRating count={r.stars} />
                <p className="text-foreground/85 text-sm leading-relaxed flex-1">"{r.text}"</p>
                <div className="pt-4 border-t border-border">
                  <div className="font-display font-bold text-foreground uppercase text-sm">{r.name}</div>
                  <div className="text-primary text-xs font-semibold mt-0.5">{r.role}</div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>

        {/* Pagination dots */}
        <div className="flex justify-center items-center gap-3">
          {Array.from({ length: total }).map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrent(i)}
              data-testid={`button-review-page-${i}`}
              className={`h-2 rounded-full transition-all duration-300 ${i === current ? "bg-primary w-8" : "bg-border w-2 hover:bg-primary/40"}`}
            />
          ))}
        </div>

        {/* Summary bar */}
        <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
          className="mt-14 flex flex-col sm:flex-row items-center justify-center gap-8 py-8 border-y border-border">
          <div className="text-center">
            <div className="text-4xl font-display font-bold text-foreground">5.0</div>
            <StarRating count={5} />
            <div className="text-xs text-muted-foreground mt-1 uppercase tracking-wide">Average Rating</div>
          </div>
          <div className="hidden sm:block w-px h-12 bg-border" />
          <div className="text-center">
            <div className="text-4xl font-display font-bold text-foreground">500+</div>
            <div className="text-xs text-muted-foreground mt-1 uppercase tracking-wide">Happy Customers</div>
          </div>
          <div className="hidden sm:block w-px h-12 bg-border" />
          <div className="text-center">
            <div className="text-4xl font-display font-bold text-foreground">8+</div>
            <div className="text-xs text-muted-foreground mt-1 uppercase tracking-wide">Years Serving Accra</div>
          </div>
          <div className="hidden sm:block w-px h-12 bg-border" />
          <div className="flex flex-col items-center gap-2">
            <a href={`https://wa.me/${WHATSAPP}?text=${encodeURIComponent("Hi, I'd like to book a service with GAB Pressure Works.")}`}
              target="_blank" rel="noopener noreferrer"
              className="bg-primary text-white px-7 py-3 rounded font-bold uppercase tracking-wider text-xs hover:bg-primary/90 hover:shadow-[0_0_20px_rgba(10,126,164,0.4)] transition-all"
              data-testid="link-review-cta">
              Join Our Happy Customers
            </a>
            <span className="text-xs text-muted-foreground">Book via WhatsApp — Fast Response</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

// ── BLOG ───────────────────────────────────────────────────────────────
const Blog = () => {
  return (
    <section id="blog" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
          <p className="text-primary font-bold uppercase tracking-[0.3em] text-xs mb-3">Knowledge Hub</p>
          <h2 className="text-4xl md:text-5xl font-display font-bold uppercase text-foreground">Pressure Knowledge Hub</h2>
          <p className="mt-4 text-muted-foreground text-lg">Tips, maintenance guides & industry news from our experts.</p>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {blogPosts.map((p, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
              className="bg-card rounded-xl overflow-hidden border border-border group hover:border-primary/40 hover:-translate-y-1 transition-all duration-300 hover:shadow-[0_8px_30px_rgba(10,126,164,0.12)]">
              <div className="h-48 bg-secondary overflow-hidden relative">
                {imgMap[p.imgKey] && <img src={imgMap[p.imgKey]} alt={p.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />}
                <div className="absolute top-4 left-4">
                  <span className="text-xs font-bold uppercase tracking-wider bg-primary text-white px-2.5 py-1 rounded">{p.cat}</span>
                </div>
              </div>
              <div className="p-6 flex flex-col">
                <h3 className="text-lg font-display font-bold mb-3 text-foreground leading-tight group-hover:text-primary transition-colors">{p.title}</h3>
                <p className="text-muted-foreground text-sm mb-4 line-clamp-2 flex-1">{p.excerpt}</p>
                <div className="flex items-center justify-between mt-auto pt-4 border-t border-border">
                  <div className="text-xs text-muted-foreground">
                    <span>{p.date}</span><span className="mx-1.5">·</span><span>{p.readTime}</span>
                  </div>
                  <Link href={`/blog/${p.slug}`} className="flex items-center gap-1 text-primary text-xs font-bold hover:gap-2 transition-all uppercase tracking-wider" data-testid={`link-read-more-${i}`}>
                    Read More <ArrowRight size={12} />
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// ── NEWSLETTER ─────────────────────────────────────────────────────────
const Newsletter = () => {
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const mutation = useSubscribeNewsletter({
    mutation: {
      onSuccess: () => {
        toast({ title: "Subscribed!", description: "Welcome to the GAB family. You'll hear from us soon." });
        setEmail("");
      },
      onError: (err: unknown) => {
        const msg = err && typeof err === "object" && "data" in err
          ? (err as { data?: { error?: string } }).data?.error
          : undefined;
        if (msg === "Already subscribed") {
          toast({ title: "Already subscribed", description: "You're already on our list — look out for updates!" });
        } else {
          toast({ title: "Something went wrong", description: "Please try again.", variant: "destructive" });
        }
      },
    },
  });

  const handleSub = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    mutation.mutate({ data: { email } });
  };

  return (
    <section className="py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary to-[#042F40]" />
      <div className="absolute inset-0 opacity-10" style={{ backgroundImage: `url(${productPump})`, backgroundSize: "cover", backgroundPosition: "center" }} />
      <div className="container mx-auto px-4 relative z-10">
        <motion.div initial={{ opacity: 0, x: -50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="max-w-3xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-display font-bold uppercase mb-4 text-white">Stay in the Know</h2>
          <p className="text-blue-100 text-lg mb-8">Get maintenance tips, product updates & exclusive deals straight to your inbox.</p>
          <form onSubmit={handleSub} className="flex flex-col sm:flex-row gap-2 max-w-xl mx-auto">
            <input
              type="email" placeholder="Enter your email address" required
              value={email} onChange={e => setEmail(e.target.value)}
              className="flex-1 px-6 py-4 rounded text-foreground outline-none focus:ring-2 focus:ring-white bg-white"
              data-testid="input-newsletter-email"
            />
            <button
              type="submit" disabled={mutation.isPending}
              className="bg-white text-primary px-8 py-4 rounded font-bold uppercase tracking-wider hover:bg-gray-100 transition whitespace-nowrap disabled:opacity-60"
              data-testid="button-subscribe"
            >
              {mutation.isPending ? "Saving..." : "Subscribe Now"}
            </button>
          </form>
          <p className="text-xs text-blue-200 mt-4 opacity-70">No spam. Unsubscribe anytime. Just value.</p>
        </motion.div>
      </div>
    </section>
  );
};

// ── CONTACT ────────────────────────────────────────────────────────────
const formSchema = z.object({
  name: z.string().min(2, "Name is required"),
  phone: z.string().min(10, "Valid phone number required"),
  email: z.string().email("Invalid email"),
  service: z.string().min(1, "Select a service"),
  message: z.string().min(10, "Message too short"),
});

const Contact = () => {
  const { toast } = useToast();
  const { register, handleSubmit, reset, formState: { errors } } = useForm<z.infer<typeof formSchema>>({ resolver: zodResolver(formSchema) });
  const mutation = useSubmitEnquiry({
    mutation: {
      onSuccess: () => {
        toast({ title: "Enquiry Sent!", description: "We've received your message and will be in touch shortly." });
        reset();
      },
      onError: () => {
        toast({ title: "Failed to send", description: "Please try again or contact us on WhatsApp.", variant: "destructive" });
      },
    },
  });
  const onSubmit = (data: z.infer<typeof formSchema>) => {
    mutation.mutate({ data });
  };

  const details = [
    { icon: MapPin, label: "Location", value: "Achimota Mile 7 Bus Stop, Accra, Ghana", href: undefined },
    { icon: Phone, label: "Phone", value: PHONE, href: `tel:${PHONE}` },
    { icon: Mail, label: "Email", value: EMAIL, href: `mailto:${EMAIL}` },
    { icon: Clock, label: "Hours", value: "Mon–Sat: 8:00 AM – 6:00 PM", href: undefined },
  ];

  return (
    <section id="contact" className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
          <p className="text-primary font-bold uppercase tracking-[0.3em] text-xs mb-3">Get in Touch</p>
          <h2 className="text-4xl md:text-5xl font-display font-bold uppercase text-foreground">Find Us. Reach Us. Trust Us.</h2>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <div className="space-y-5 mb-10">
              {details.map(({ icon: Icon, label, value, href }, i) => (
                <motion.div key={i} initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                  className="flex items-start gap-4">
                  <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center text-primary shrink-0">
                    <Icon size={18} />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm uppercase tracking-wide mb-0.5 text-foreground">{label}</h4>
                    {href
                      ? <a href={href} className="text-muted-foreground hover:text-primary transition-colors text-sm">{value}</a>
                      : <p className="text-muted-foreground text-sm">{value}</p>}
                  </div>
                </motion.div>
              ))}
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 bg-card p-8 rounded-xl border border-border">
              <h3 className="text-2xl font-display font-bold uppercase mb-2">Send an Enquiry</h3>
              <div>
                <input {...register("name")} placeholder="Full Name" className="w-full px-4 py-3 rounded-lg border bg-background border-input text-foreground focus:ring-1 focus:ring-primary outline-none text-sm" data-testid="input-name" />
                {errors.name && <span className="text-red-500 text-xs mt-1 block">{errors.name.message}</span>}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <input {...register("phone")} placeholder="Phone" className="w-full px-4 py-3 rounded-lg border bg-background border-input text-foreground focus:ring-1 focus:ring-primary outline-none text-sm" data-testid="input-phone" />
                  {errors.phone && <span className="text-red-500 text-xs mt-1 block">{errors.phone.message}</span>}
                </div>
                <div>
                  <input {...register("email")} placeholder="Email" className="w-full px-4 py-3 rounded-lg border bg-background border-input text-foreground focus:ring-1 focus:ring-primary outline-none text-sm" data-testid="input-email" />
                  {errors.email && <span className="text-red-500 text-xs mt-1 block">{errors.email.message}</span>}
                </div>
              </div>
              <div>
                <select {...register("service")} className="w-full px-4 py-3 rounded-lg border bg-background border-input text-foreground focus:ring-1 focus:ring-primary outline-none text-sm" data-testid="select-service">
                  <option value="">Select Service Needed</option>
                  <option value="pump-repair">Pump Repairs</option>
                  <option value="buy-pump">Buy a Pump</option>
                  <option value="buy-gun">Buy a Pressure Gun</option>
                  <option value="buy-hose">Buy a Hose</option>
                  <option value="buy-valve">Valves & Fittings</option>
                  <option value="coating">Coating Solutions</option>
                  <option value="other">Other Enquiry</option>
                </select>
                {errors.service && <span className="text-red-500 text-xs mt-1 block">{errors.service.message}</span>}
              </div>
              <div>
                <textarea {...register("message")} rows={4} placeholder="Your Message" className="w-full px-4 py-3 rounded-lg border bg-background border-input text-foreground focus:ring-1 focus:ring-primary outline-none text-sm resize-none" data-testid="textarea-message" />
                {errors.message && <span className="text-red-500 text-xs mt-1 block">{errors.message.message}</span>}
              </div>
              <button type="submit" disabled={mutation.isPending} className="w-full bg-primary text-white py-4 rounded-lg font-bold uppercase tracking-wider hover:bg-primary/90 hover:shadow-[0_0_20px_rgba(10,126,164,0.4)] transition-all disabled:opacity-50 text-sm" data-testid="button-send-enquiry">
                {mutation.isPending ? "Sending..." : "Send Enquiry"}
              </button>
            </form>
          </div>

          <motion.div
            initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}
            className="flex flex-col gap-4"
          >
            {/* Map */}
            <div className="h-72 lg:h-96 bg-muted rounded-xl overflow-hidden border border-border">
              <iframe
                title="GAB Pressure Works Location"
                src="https://maps.google.com/maps?q=Mile+7+Achimota+Accra+Ghana&t=&z=15&ie=UTF8&iwloc=&output=embed"
                width="100%" height="100%" style={{ border: 0 }} allowFullScreen loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
            {/* Directions CTA */}
            <a
              href="https://maps.google.com/?q=Mile+7+Achimota+Accra+Ghana"
              target="_blank" rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3.5 rounded-xl border border-primary text-primary font-bold uppercase tracking-wider text-sm hover:bg-primary hover:text-white transition-all"
              data-testid="link-directions"
            >
              <MapPin size={15} />
              Get Directions — Achimota Mile 7
            </a>
            {/* Social quick links */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <a href={`https://wa.me/${WHATSAPP}?text=${encodeURIComponent("Hi, I'd like to make an enquiry.")}`}
                target="_blank" rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-3 rounded-xl bg-green-600 text-white font-bold text-xs uppercase tracking-wider hover:bg-green-700 transition-colors"
                data-testid="link-contact-whatsapp">
                <FaWhatsapp size={15} /> Chat on WhatsApp
              </a>
              <a href={`tel:${PHONE}`}
                className="flex items-center justify-center gap-2 py-3 rounded-xl bg-primary/10 text-primary font-bold text-xs uppercase tracking-wider border border-primary/20 hover:bg-primary hover:text-white transition-colors"
                data-testid="link-contact-call">
                <Phone size={14} /> Call Us Now
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

// ── FOOTER ─────────────────────────────────────────────────────────────
const Footer = () => (
  <footer className="bg-[#042F40] text-blue-100/70 pt-16 pb-8">
    <div className="container mx-auto px-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-14">
        <div>
          <h3 className="text-2xl font-display font-bold uppercase text-white mb-1 leading-tight">
            <span className="text-primary">GAB</span> PRESSURE WORKS
          </h3>
          <p className="text-primary text-xs uppercase tracking-widest font-bold mb-4">Precision. Pressure. Performance.</p>
          <p className="text-sm leading-relaxed">Accra's most trusted pressure equipment specialist. Sales, repairs & maintenance at Achimota Mile 7.</p>
        </div>
        <div>
          <h4 className="text-white font-bold uppercase tracking-wider mb-5 text-sm">Quick Links</h4>
          <ul className="space-y-2.5 text-sm">
            {["#home:Home", "#products:Products", "#services:Services", "#about:About Us", "#blog:Blog", "#contact:Contact"].map(item => {
              const [href, name] = item.split(":");
              return <li key={href}><a href={href} className="hover:text-primary transition-colors">{name}</a></li>;
            })}
          </ul>
        </div>
        <div>
          <h4 className="text-white font-bold uppercase tracking-wider mb-5 text-sm">Services</h4>
          <ul className="space-y-2.5 text-sm">
            {["Pump Repairs", "Pressure Guns", "Valves & Fittings", "Pressure Hoses", "Coating Solutions", "Same-Day Repairs"].map(s => (
              <li key={s}><a href="#services" className="hover:text-primary transition-colors">{s}</a></li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="text-white font-bold uppercase tracking-wider mb-5 text-sm">Contact</h4>
          <div className="space-y-3 text-sm mb-6">
            <p><a href={`tel:${PHONE}`} className="hover:text-primary transition-colors flex items-center gap-2"><Phone size={13} className="text-primary" />{PHONE}</a></p>
            <p><a href={`mailto:${EMAIL}`} className="hover:text-primary transition-colors flex items-center gap-2"><Mail size={13} className="text-primary" />{EMAIL}</a></p>
            <p className="flex items-center gap-2"><Clock size={13} className="text-primary" />Mon–Sat: 8am–6pm</p>
          </div>
          <div className="flex gap-3 flex-wrap">
            {[
              { icon: FaWhatsapp, href: `https://wa.me/${WHATSAPP}`, label: "WhatsApp" },
              { icon: FaInstagram, href: "https://www.instagram.com/gab_pressure_works", label: "Instagram" },
              { icon: FaTiktok, href: "https://www.tiktok.com/@gab.pressure.work", label: "TikTok" },
              { icon: FaEnvelope, href: `mailto:${EMAIL}`, label: "Email" },
            ].map(({ icon: Icon, href, label }, i) => (
              <a key={i} href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer"
                aria-label={label}
                className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center hover:bg-primary text-white transition-colors">
                <Icon size={16} />
              </a>
            ))}
          </div>
        </div>
      </div>
      <div className="border-t-2 border-primary pt-6 flex flex-col md:flex-row justify-between items-center text-xs gap-2">
        <p>© 2025 GAB Pressure Works. All Rights Reserved.</p>
        <p className="text-white font-bold tracking-wider uppercase">Achimota Mile 7, Accra, Ghana</p>
      </div>
    </div>
  </footer>
);

// ── CHAT WIDGET ────────────────────────────────────────────────────────
const ChatWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [msg, setMsg] = useState("");

  const handleQuickReply = (text: string) => {
    window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(text)}`, "_blank");
  };
  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (msg.trim()) { handleQuickReply(msg); setMsg(""); }
  };

  return (
    <>
      <button onClick={() => setIsOpen(true)} data-testid="button-chat-open"
        className={`fixed bottom-6 right-6 z-50 w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center shadow-2xl shadow-primary/40 animate-[pulse_5s_infinite] transition-transform ${isOpen ? "scale-0" : "scale-100 hover:scale-110"}`}>
        <MessageCircle size={28} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div initial={{ opacity: 0, y: 20, scale: 0.9 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="fixed bottom-0 md:bottom-6 md:right-6 z-[60] w-full md:w-[360px] bg-background border border-border shadow-2xl md:rounded-2xl overflow-hidden flex flex-col max-h-[80vh]">
            <div className="bg-primary text-white p-4 flex justify-between items-center">
              <div className="font-bold flex items-center gap-2 text-sm">
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                GAB Pressure Works — Live Support
              </div>
              <button onClick={() => setIsOpen(false)} className="hover:bg-white/20 p-1 rounded" data-testid="button-chat-close"><X size={20} /></button>
            </div>
            <div className="p-4 bg-muted/30 flex-1 overflow-y-auto space-y-4">
              <div className="bg-card border border-border p-3 rounded-lg rounded-tl-none shadow-sm text-sm leading-relaxed">
                Hi! Welcome to GAB Pressure Works 👋 How can we help you today?
              </div>
              <div className="flex flex-col gap-2 pt-2">
                {["I need a pump repair", "I want to buy equipment", "I need a pressure wash service", "I want to speak to someone"].map(opt => (
                  <button key={opt} onClick={() => handleQuickReply(opt)} data-testid={`button-quick-reply-${opt.slice(0, 10)}`}
                    className="text-left px-4 py-2.5 text-sm bg-primary/10 hover:bg-primary/20 text-primary rounded-full transition-colors border border-primary/20 font-medium">
                    {opt}
                  </button>
                ))}
              </div>
            </div>
            <form onSubmit={handleSend} className="p-3 bg-background border-t border-border flex gap-2">
              <input type="text" value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Type your message..." data-testid="input-chat-message"
                className="flex-1 bg-muted px-3 py-2 rounded-full text-sm outline-none border border-transparent focus:border-primary" />
              <button type="submit" className="w-10 h-10 bg-primary text-white rounded-full flex items-center justify-center shrink-0" data-testid="button-chat-send">
                <Send size={16} />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

// ── PAGE ───────────────────────────────────────────────────────────────
export default function Home() {
  return (
    <main className="min-h-screen font-sans">
      <Navbar />
      <Hero />
      <Products />
      <Services />
      <WhyUs />
      <About />
      <Testimonials />
      <Blog />
      <Newsletter />
      <Contact />
      <Footer />
      <ChatWidget />
    </main>
  );
}
