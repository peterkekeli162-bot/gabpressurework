import { Router, type IRouter } from "express";
import { db, newsletterTable } from "@workspace/db";
import { SubscribeNewsletterBody } from "@workspace/api-zod";
import { notifyNewsletter } from "../lib/notify";

const router: IRouter = Router();

router.post("/newsletter", async (req, res): Promise<void> => {
  const parsed = SubscribeNewsletterBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    const [record] = await db.insert(newsletterTable).values(parsed.data).returning();

    req.log.info({ email: record.email }, "Newsletter subscriber saved");

    await notifyNewsletter({
      email: record.email,
      createdAt: record.createdAt.toISOString(),
    });

    res.status(201).json({
      ...record,
      createdAt: record.createdAt.toISOString(),
    });
  } catch (err: unknown) {
    const pgCode = (
      err &&
      typeof err === "object" &&
      "cause" in err &&
      err.cause &&
      typeof err.cause === "object" &&
      "code" in err.cause
    )
      ? (err.cause as { code: string }).code
      : (err && typeof err === "object" && "code" in err)
        ? (err as { code: string }).code
        : undefined;

    if (pgCode === "23505") {
      res.status(409).json({ error: "Already subscribed" });
      return;
    }
    throw err;
  }
});

export default router;
