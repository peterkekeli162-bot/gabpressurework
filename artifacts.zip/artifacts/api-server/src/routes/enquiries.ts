import { Router, type IRouter } from "express";
import { db, enquiriesTable } from "@workspace/db";
import { SubmitEnquiryBody } from "@workspace/api-zod";
import { notifyEnquiry } from "../lib/notify";

const router: IRouter = Router();

router.post("/enquiries", async (req, res): Promise<void> => {
  const parsed = SubmitEnquiryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [record] = await db.insert(enquiriesTable).values(parsed.data).returning();

  req.log.info({ id: record.id, service: record.service }, "Enquiry saved");

  await notifyEnquiry({
    name: record.name,
    phone: record.phone,
    email: record.email,
    service: record.service,
    message: record.message,
    createdAt: record.createdAt.toISOString(),
  });

  res.status(201).json({
    ...record,
    createdAt: record.createdAt.toISOString(),
  });
});

export default router;
