import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { db, enquiriesTable, newsletterTable } from "@workspace/db";
import { AdminLoginBody } from "@workspace/api-zod";
import { desc } from "drizzle-orm";
import { logger } from "../lib/logger";

const router: IRouter = Router();

function adminAuth(req: Request, res: Response, next: NextFunction): void {
  const adminPassword = process.env.ADMIN_PASSWORD;
  if (!adminPassword) {
    logger.warn("ADMIN_PASSWORD env var not set — admin routes disabled");
    res.status(503).json({ error: "Admin not configured" });
    return;
  }

  const authHeader = req.headers.authorization ?? "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";

  if (token !== adminPassword) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
}

router.post("/admin/login", (req, res): void => {
  const adminPassword = process.env.ADMIN_PASSWORD;
  if (!adminPassword) {
    res.status(503).json({ error: "Admin not configured" });
    return;
  }

  const parsed = AdminLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Password required" });
    return;
  }

  if (parsed.data.password !== adminPassword) {
    res.status(401).json({ error: "Wrong password" });
    return;
  }

  res.json({ ok: true });
});

router.get("/admin/enquiries", adminAuth, async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(enquiriesTable)
    .orderBy(desc(enquiriesTable.createdAt));

  res.json(rows.map(r => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.get("/admin/newsletter", adminAuth, async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(newsletterTable)
    .orderBy(desc(newsletterTable.createdAt));

  res.json(rows.map(r => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

export default router;
