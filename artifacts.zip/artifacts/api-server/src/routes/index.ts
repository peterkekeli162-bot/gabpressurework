import { Router, type IRouter } from "express";
import healthRouter from "./health";
import enquiriesRouter from "./enquiries";
import newsletterRouter from "./newsletter";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(enquiriesRouter);
router.use(newsletterRouter);
router.use(adminRouter);

export default router;
