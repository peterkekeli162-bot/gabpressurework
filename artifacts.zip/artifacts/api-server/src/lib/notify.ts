import nodemailer from "nodemailer";
import { logger } from "./logger";

interface EnquiryPayload {
  name: string;
  phone: string;
  email: string;
  service: string;
  message: string;
  createdAt: string;
}

interface NewsletterPayload {
  email: string;
  createdAt: string;
}

function createTransport() {
  const host = process.env.SMTP_HOST;
  const port = Number(process.env.SMTP_PORT ?? "587");
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (!host || !user || !pass) return null;

  return nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: { user, pass },
  });
}

async function fireWebhook(url: string, data: Record<string, unknown>) {
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      logger.warn({ status: res.status, url }, "Webhook responded with non-2xx");
    }
  } catch (err) {
    logger.warn({ err, url }, "Failed to fire webhook");
  }
}

export async function notifyEnquiry(payload: EnquiryPayload): Promise<void> {
  const notifyEmail = process.env.NOTIFY_EMAIL ?? "gabpressureworks@gmail.com";
  const zapierUrl = process.env.ZAPIER_ENQUIRY_WEBHOOK_URL;

  // — Email notification
  const transport = createTransport();
  if (transport) {
    try {
      await transport.sendMail({
        from: `"GAB Pressure Works Website" <${process.env.SMTP_USER}>`,
        to: notifyEmail,
        subject: `New Enquiry from ${payload.name} — ${payload.service}`,
        html: `
          <h2 style="color:#0A7EA4">New Customer Enquiry</h2>
          <table style="border-collapse:collapse;width:100%;font-family:sans-serif">
            <tr><td style="padding:8px;font-weight:bold;color:#042F40">Name</td><td style="padding:8px">${payload.name}</td></tr>
            <tr style="background:#f5f9fc"><td style="padding:8px;font-weight:bold;color:#042F40">Phone</td><td style="padding:8px"><a href="tel:${payload.phone}">${payload.phone}</a></td></tr>
            <tr><td style="padding:8px;font-weight:bold;color:#042F40">Email</td><td style="padding:8px"><a href="mailto:${payload.email}">${payload.email}</a></td></tr>
            <tr style="background:#f5f9fc"><td style="padding:8px;font-weight:bold;color:#042F40">Service</td><td style="padding:8px">${payload.service}</td></tr>
            <tr><td style="padding:8px;font-weight:bold;color:#042F40">Message</td><td style="padding:8px">${payload.message}</td></tr>
            <tr style="background:#f5f9fc"><td style="padding:8px;font-weight:bold;color:#042F40">Received</td><td style="padding:8px">${payload.createdAt}</td></tr>
          </table>
          <p style="margin-top:20px;color:#666;font-size:12px">Sent from gabpressureworks.com contact form</p>
        `,
      });
      logger.info({ to: notifyEmail }, "Enquiry email sent");
    } catch (err) {
      logger.error({ err }, "Failed to send enquiry email");
    }
  } else {
    logger.warn("SMTP not configured — skipping enquiry email notification");
  }

  // — Zapier webhook (for automated reply)
  if (zapierUrl) {
    await fireWebhook(zapierUrl, {
      type: "enquiry",
      ...payload,
    });
    logger.info({ url: zapierUrl }, "Enquiry webhook fired");
  }
}

export async function notifyNewsletter(payload: NewsletterPayload): Promise<void> {
  const notifyEmail = process.env.NOTIFY_EMAIL ?? "gabpressureworks@gmail.com";
  const zapierUrl = process.env.ZAPIER_NEWSLETTER_WEBHOOK_URL;

  const transport = createTransport();
  if (transport) {
    try {
      await transport.sendMail({
        from: `"GAB Pressure Works Website" <${process.env.SMTP_USER}>`,
        to: notifyEmail,
        subject: `New Newsletter Subscriber: ${payload.email}`,
        html: `
          <h2 style="color:#0A7EA4">New Newsletter Subscriber</h2>
          <p><strong>Email:</strong> <a href="mailto:${payload.email}">${payload.email}</a></p>
          <p><strong>Subscribed at:</strong> ${payload.createdAt}</p>
          <p style="color:#666;font-size:12px">Sent from gabpressureworks.com</p>
        `,
      });
      logger.info({ to: notifyEmail }, "Newsletter email sent");
    } catch (err) {
      logger.error({ err }, "Failed to send newsletter email");
    }
  } else {
    logger.warn("SMTP not configured — skipping newsletter email notification");
  }

  if (zapierUrl) {
    await fireWebhook(zapierUrl, {
      type: "newsletter",
      ...payload,
    });
    logger.info({ url: zapierUrl }, "Newsletter webhook fired");
  }
}
